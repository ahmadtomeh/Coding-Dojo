from django.apps import AppConfig


class AppExamConfig(AppConfig):
    name = 'app_exam'
